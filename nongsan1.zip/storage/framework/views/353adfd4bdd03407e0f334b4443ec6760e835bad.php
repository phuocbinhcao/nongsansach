<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('css/admin/detail.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- Modal Customer -->
<div class="modal fade" id="historyCustomerModal" tabindex="-1" role="dialog"
    aria-labelledby="historyCustomerModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content  ">
            <div class="modal-header bg-c-lite-green">
                <h5 class="modal-title text-white" id="historyCustomerModalLabel">Lịch sử mua hàng</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-sm-6">
                        <h6 class="text-muted f-w-400">Tên khách hàng</h6>
                        <p class="m-b-10 f-w-600"><?php echo e($customer->customer_name); ?></p>
                    </div>
                    <div class="col-sm-6">
                        <p class="m-b-10 f-w-600">SĐT</p>
                        <h6 class="text-muted f-w-400"><?php echo e($customer->customer_phone); ?></h6>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <table class="table f-s-13 card">
                            <thead class="tbl-bg-color text-white">
                                <tr>
                                    <th>Tên sản phẩm</th>
                                    <th>Ký hiệu</th>
                                    <th>Số lượng</th>
                                    <th>Giá</th>
                                    <th>Mô tả</th>
                                    <th>Ngày</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dataOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($order->product_name); ?></td>
                                    <td><?php echo e($order->product_symbol); ?></td>
                                    <td><?php echo e($order->order_detail_quantity); ?></td>
                                    <td><?php echo e($order->order_detail_price); ?></td>
                                    <td><?php echo e($order->product_description); ?></td>
                                    <td><?php echo e($order->created_at); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Infor Customer -->

    <div class="page-content page-container" id="page-content">
        <div class="padding">
            <div class="row container d-flex justify-content-center">
                <div class="col-xl-6 col-md-12">
                    <div class="card user-card-full">
                        <div class="row m-l-0 m-r-0">
                            <div class="col-sm-4 bg-c-lite-green user-profile">
                                <div class="card-block text-center text-white">
                                    <div class="m-b-25"> <img src="<?php echo e(url('img/users/client.jpg')); ?>" width="100px"
                                            class="img-radius" alt="User-Profile-Image"> </div>
                                    <h6 class="f-w-600"><?php echo e($customer->customer_name); ?></h6>
                                    <p>Khách hàng</p> <i
                                        class=" mdi mdi-square-edit-outline feather icon-edit m-t-10 f-16"></i>
                                </div>
                            </div>
                            <div class="col-sm-8">
                                <div class="card-block">
                                    <h6 class="m-b-20 p-b-5 b-b-default f-w-600">Thông tin</h6>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <p class="m-b-10 f-w-600">Email</p>
                                            <h6 class="text-muted f-w-400"><?php echo e($customer->customer_email); ?></h6>
                                        </div>
                                        <div class="col-sm-6">
                                            <p class="m-b-10 f-w-600">SĐT</p>
                                            <h6 class="text-muted f-w-400"><?php echo e($customer->customer_phone); ?></h6>
                                        </div>
                                        <div class="col-sm-6">
                                            <p class="m-b-10 f-w-600">Địa chỉ</p>
                                            <h6 class="text-muted f-w-400"><?php echo e($customer->customer_address); ?></h6>
                                        </div>

                                    </div>
                                    <h6 class="m-b-20 m-t-40 p-b-5 b-b-default f-w-600">User Account</h6>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <p class="m-b-10 f-w-600">Email</p>
                                            <h6 class="text-muted f-w-400"><?php echo e($customer->customer_email); ?></h6>
                                        </div>
                                        <div class="col-sm-6">
                                            <p class="m-b-10 f-w-600">Vai trò</p>
                                            <h6 class="text-muted f-w-400">Khách hàng</h6>
                                        </div>
                                        <div class="col-sm-6">
                                            <p class="m-b-10 f-w-600">Ngày đăng ký</p>
                                            <h6 class="text-muted f-w-400"><?php echo e($customer->created_at); ?></h6>
                                        </div>
                                        <div class="col-sm-6">
                                            <a href="" class="badge badge-primary" data-toggle="modal"
                                                data-target="#historyCustomerModal">Lịch sử mua hàng</a>
                                        </div>
                                    </div>
                                    <div class="p-2 text-right">
                                        <a href="<?php echo e(route('customers.index')); ?>" class="badge badge-primary"> Trờ lại </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/customer/historyCustomer.blade.php ENDPATH**/ ?>