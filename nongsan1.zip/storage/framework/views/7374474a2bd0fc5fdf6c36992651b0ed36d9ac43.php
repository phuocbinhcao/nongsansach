<?php $__env->startSection('styles'); ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo e(config('app.name', 'Laravel')); ?></title>

<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css" />
 <!-- Default theme -->
 <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/default.min.css" />
<!-- CSS -->
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="<?php echo e(asset('jquery-ui-1.13.0/jquery-ui.min.css')); ?>">
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card-header py-3">
        <p class="m-0 font-weight-bold text-primary">
            <a href="<?php echo e(route('order.index')); ?>" class="border border-primary rounded text-decoration-none">
                Danh sách đơn hàng</a>
            <span> <i class="fas fa-chevron-right"></i>Thêm đơn hàng</span>
        </p>
    </div>
    <div class="card-body ">
        <div id="card-table">

            <form method="POST" action="<?php echo e(route('order.store')); ?>">

                <!--Form Orders  -->
                <div id="table">
                    <table class="  table table-bordered text-monospace update_cart_url" data-url="<?php echo e(route('updateCart')); ?>">
                        <thead>
                            <tr>
                                <th>Tên sản phẩm</th>
                                <th>Giá sản phẩm(VNĐ)</th>
                                <th>Số lượng(Kg)</th>
                                <th>Tông tiền</th>
                                <th>Chức năng</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total = 0;
                            ?>
                            <?php if(session()->get('cart') !== null): ?>
                            <?php $__currentLoopData = $carts = session()->get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $total += $cart['price'] * $cart['quantity'];
                            ?>
                            <tr>
                                <td><?php echo e($cart['name']); ?></td>
                                <td><?php echo e(number_format($cart['price'])); ?></td>
                                <td>
                                    <input type="number" min="1" name="product_quantity" class="w-25 quatity"
                                        value="<?php echo e($cart['quantity']); ?>">
                                </td>
                                <td> <?php echo e(number_format($cart['price']*$cart['quantity'])); ?></td>
                                <td><a href="javascript:" data-id="<?php echo e($id); ?>" class="btn-sm btn-primary cart_update">Update</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <h2 name="total_price">Tổng tiền: <?php echo e(number_format($total)); ?> VNĐ</h2>
                        </tfoot>
                    </table>
                </div>
                <div class="card-footer">
                    <div class="mb-3 row ">
                        <label class="col-sm-2 col-form-label">Tên khách hàng</label>
                        <div class="col-sm-4">
                            <input name="customer_name" id='customer_name' type="text" class="form-control"
                                placeholder="Nguyen Van A">
                             <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-warning">
                                    <span class="text-danger"><strong><?php echo e($message); ?></strong></span>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <label class="col-sm-2 col-form-label">SĐT</label>
                        <div class="col-sm-4">
                            <input name="customer_phone" id='customer_phone' type="text" class="form-control"
                                placeholder="+84123456789" autocomplete="text">
                             <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-warning">
                                    <span class="text-danger"><strong><?php echo e($message); ?></strong></span>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label">Địa chỉ</label>
                        <div class="col-sm-4">
                            <input name="customer_address" id='customer_address' type="text" class="form-control" placeholder="">
                             <?php $__errorArgs = ['customer_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-warning">
                                    <span class="text-danger"><strong><?php echo e($message); ?></strong></span>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <label class="col-sm-2 col-form-label">Email</label>
                        <div class="col-sm-4">
                            <input name="customer_email" id='customer_email' type="text" class="form-control"
                                placeholder="email@example.com">
                             <?php $__errorArgs = ['customer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-warning">
                                    <span class="text-danger"><strong><?php echo e($message); ?></strong></span>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label">Trạng thái</label>
                        <div class="col-sm-4">
                            <select name="order_status" class="form-control">
                                <option value="0">---</option>
                                <option value="Tiếp nhận">Tiếp nhận</option>
                                <option value="Đang giao">Đang giao</option>
                                <option value="Đã giao">Đã giao</option>
                                <option value="Hủy">Hủy</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Thanh toán</button>
                    <button type="button" class="btn btn-primary"  ><a href="<?php echo e(route('order.create')); ?>" class="text-white">Thêm đơn hàng  </a>  </button>
                </div>

                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>
</div>


<?php $__env->startSection('scripts'); ?>
<!-- Script -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
 <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>


<!-- Script code  -->
<script type="text/javascript">
    // CSRF Token,  Autocomplete
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $(document).ready(function () {

        $("#customer_phone").autocomplete({
            source: function (request, response) {
                // Fetch data
                $.ajax({
                    url: "<?php echo e(route('getCustomers')); ?>",
                    type: 'post',
                    dataType: "json",
                    data: {
                        _token: CSRF_TOKEN,
                        search: request.term
                    },
                    success: function (data) {
                        response(data);
                        console.log(data);
                    }
                });
            },
            select: function (event, ui) {
                // Set selection
                $('#customer_phone').val(ui.item.phone); // display the selected text
                $('#customer_name').val(ui.item.label); // save selected name to input
                $('#customer_email').val(ui.item.email); // save selected email to input
                $('#customer_address').val(ui.item.address); // save selected email to input
                return false;
            }
        });

    });

    function cartUpdate(event) {
        event.preventDefault();
        let urlUpdateCart = $('.update_cart_url').data('url');
        let id = $(this).data('id');
        let quatity = $(this).parents('tr').find('input.quatity').val();
        $.ajax({
            type: "GET",
            url: urlUpdateCart,
            data: {
                id: id,
                quatity: quatity
            },
            success: function (data) {
                    $('#table').load(' #table');
                    alertify.set('notifier', 'position', 'top-center');
                    alertify.success('Thay đổi thành công');
            }
        });
    }
    $(function () {
        $(document).on('click', '.cart_update', cartUpdate);
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/orders/showOrders.blade.php ENDPATH**/ ?>