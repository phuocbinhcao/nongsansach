<?php $__env->startSection('content'); ?>

<div class="card-header py-3">
    <p class="m-0 font-weight-bold text-primary">
        <a href="<?php echo e(route('warehouses.index')); ?>" class="border border-primary rounded text-decoration-none">
        Danh sách lô hàng</a>
        <span> <i class="fas fa-chevron-right"></i>Thêm lô hàng</span>
    </p>
</div>
<div class="card-body  justify-content-center  ">
    <form method="POST" action="<?php echo e(route('warehouses.store')); ?>" class="w-75 mx-auto">
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Ký hiệu</label>
            <div class="col-sm-4">
                <input name="consignment_symbol" type="text" class="form-control" placeholder="Ký hiệu lô hàng">
                <?php $__errorArgs = ['consignment_symbol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-warning">
                        <span class="text-danger"><strong><?php echo e($message); ?></strong></span>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <label class="col-sm-2 col-form-label">Tên lô hàng</label>
            <div class="col-sm-4">
                <input name="consignment_name" type="text" class="form-control" placeholder="Ký hiệu lô hàng">
                <?php $__errorArgs = ['consignment_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-warning">
                        <span class="text-danger"><strong><?php echo e($message); ?></strong></span>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Hạn sử dụng</label>
            <div class="col-sm-4">
                <input name="consignment_expiry" type="date" class="form-control" placeholder="Ngày tháng">
                <?php $__errorArgs = ['consignment_expiry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-warning">
                        <span class="text-danger"><strong><?php echo e($message); ?></strong></span>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Giá mua vào (Vnd)</label>
            <div class="col-sm-4 ">
                <input name="consignment_purchase_price" type="text" class="form-control"
                    placeholder="Giá mua vào  ">
                <?php $__errorArgs = ['consignment_purchase_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-warning">
                        <span class="text-danger"><strong><?php echo e($message); ?></strong></span>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <label class="col-sm-2 col-form-label">Giá bán ra (Vnd)</label>
            <div class="col-sm-4">
                <input name="consignment_sale_price" type="text" class="form-control" placeholder="Giá bán ra  ">
                <?php $__errorArgs = ['consignment_sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-warning">
                        <span class="text-danger"><strong><?php echo e($message); ?></strong></span>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Số lượng nhập (Kg)</label>
            <div class="col-sm-4">
                <input name="consignment_quantity" type="number" class="form-control" placeholder="Số lượng nhập">
                <?php $__errorArgs = ['consignment_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-warning">
                        <span class="text-danger"><strong><?php echo e($message); ?></strong></span>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Sản phẩm</label>
            <div class="col-sm-6">
                <select name="product_id" class="form-control">
                    <option value="">---</option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->product_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Nhà cung cấp</label>
            <div class="col-sm-6">
                <select name="supplier_id" class="form-control">
                    <option value="">---</option>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sup->id); ?>"><?php echo e($sup->supplier_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <?php echo csrf_field(); ?>
        <button class="btn btn-primary">Thêm</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/warehouse/create.blade.php ENDPATH**/ ?>