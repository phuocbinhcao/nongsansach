<?php $__env->startSection('content'); ?>
<!--Checkout page section-->
<div class="Checkout_page_section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="customer-login mb-40">
                    <h3>
                        <i class="fa fa-file-o" aria-hidden="true"></i>
                        Trở thành thành viên?
                        <a class="Returning text-success" href="#">Nhấp vào đây để đăng ký</a>

                    </h3>
                </div>
            </div>
        </div>
        <div class="checkout-form">
            <form action="<?php echo e(route('paybycash.cart')); ?>" method="POST">
            <div class="row">
                <?php if(Auth::user() == null): ?>
                    <div class="col-lg-6 col-md-6">
                        <?php echo csrf_field(); ?>
                        <h3>Chi tiết đơn hàng</h3>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-warning">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($error); ?><br />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-lg-6 mb-30">
                                <label for="b_name">Tên khách hàng<span>*</span></label>
                                <input id="b_name" type="text" name="name">
                            </div>
                            <div class="col-12 mb-30">
                                <label>Địa chỉ <span>*</span></label>
                                <input placeholder="Tên đường( Thôn)/ Phường( Xã)/ Quận( Huyện)/ Thành phố (Tỉnh)" type="text" name="address">
                            </div>
                            <div class="col-lg-6 mb-30">
                                <label for="b_email">Địa chỉ Email<span>*</span></label>
                                <input id="b_email" type="text" name="email" placeholder="a@google.com">
                            </div>
                            <div class="col-lg-6 mb-30">
                                <label>Số điện thoại <span>*</span></label>
                                <input placeholder="Phone Number" type="text" name="phone">
                            </div>
                            <div class="col-12 mb-30">
                                <input id="b_c_account" type="checkbox" data-target="createp_account" />
                                <label class="righ_0" for="b_c_account" data-toggle="collapse"
                                    data-target="#collapseOne" aria-controls="collapseOne">Tạo tài khoản</label>

                                <div id="collapseOne" class="collapse" data-parent="#accordion">
                                    <div class="card-body1">
                                        <p>Create an account by entering the information below. If you are a returning
                                            customer please login at the top of the page.</p>
                                        <label for="b_a_password">Account password <span>*</span></label>
                                        <input id="b_a_password" type="password" name="password">
                                    </div>
                                    <div class="card-body1">

                                        <label for="b_a_password">Confirm password <span>*</span></label>
                                        <input id="b_a_password" type="password" name="password_confirmation">
                                    </div>
                                </div>

                            </div>
                            <div class="col-12">
                                <div class="order-notes">
                                    <label for="order_note">Ghi chú</label>
                                    <textarea id="order_note" name="customer_name"
                                        placeholder="Ghi chú thông tin cần thiết về đơn hàng của bạn, quan trọng cho việc giao hàng"></textarea>
                                </div>
                            </div>
                        </div>

                    </div>
                <?php endif; ?>
                    <div class="col-lg-6 col-md-6">
                        <div class="order-wrapper">
                            <h3>Đơn hàng của bạn</h3>
                            <div class="order-table table-responsive mb-30">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="product-name">Sản Phẩm</th>
                                            <th class="product-total">Tổng tiền</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $total= 0
                                        ?>
                                        <?php $__currentLoopData = $carts = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td class="product-name"><?php echo e($cart['name']); ?> x <strong class="bordered rounded text-white bg-danger px-1">
                                                    <?php echo e($cart['quantity']); ?></strong></td>
                                            <td class="amount"><?php echo e(number_format($cart['price']*$cart['quantity'])); ?>Vnd
                                            </td>
                                        </tr>
                                        <?php
                                        $total += $cart['price']*$cart['quantity']
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Tổng tiền giỏ hàng</th>
                                            <td><?php echo e(number_format($total)); ?>Vnd</td>
                                        </tr>
                                        <tr>
                                            <th>Tổng tiền đơn hàng (phụ phí)</th>
                                            <td><strong><?php echo e(number_format($total*1.05)); ?> Vnd(VAT: 5%)</strong></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <div class="payment-method d-flex justify-content-center">
                                
                                    <div class="order-button1 mr-2">
                                        <button type="submit">Thanh toán (Tiền mặt)</button>
                                    </div>
                                
                                <div class="order-button2">
                                    <button type="submit" name="payonline">Thanh toán Online</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!--Checkout page section end-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://unpkg.com/sweetalert@2.1.2/dist/sweetalert.min.js"></script>

<?php if(session()->get('haveordered')): ?>
<script>
    swal("Goods job", "Order has been booked successfully", "success");
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/frontend/cart/checkout.blade.php ENDPATH**/ ?>