<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
<div class="alert alert-warning">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($error); ?><br />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<div class="card-header py-3">
    <p class="m-0 font-weight-bold text-primary">
       <a href="<?php echo e(route('suppliers.index')); ?>" class="border border-primary rounded text-decoration-none">Danh sách nhà cung cấp</a>
        <span> <i class="fas fa-chevron-right"></i>Sửa thông tin nhà cung cấp</span>
    </p>
</div>
<div class="card-body">
    <form method="POST" action="<?php echo e(route('suppliers.update',$supplier->id)); ?>">
        <div class="mb-3 row">
            <label for=" " class="col-sm-2 col-form-label">Nhà cung cấp</label>
            <div class="col-sm-10">
                <input name="supplier_name" type="text" class="form-control" value="<?php echo e($supplier->supplier_name); ?>">
            </div>
        </div>
        <div class="mb-3 row">
            <label for=" " class="col-sm-2 col-form-label">Địa chỉ</label>
            <div class="col-sm-10">
                <input name="supplier_address" type="text" class="form-control" value="<?php echo e($supplier->supplier_address); ?>">
            </div>
        </div>
        <div class="mb-3 row">
            <label for=" " class="col-sm-2 col-form-label">SĐT</label>
            <div class="col-sm-10">
                <input name="supplier_phone" type="text" class="form-control" value="<?php echo e($supplier->supplier_phone); ?>">
            </div>
        </div>
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <button class="btn btn-primary">Sửa</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/suppliers/edit.blade.php ENDPATH**/ ?>