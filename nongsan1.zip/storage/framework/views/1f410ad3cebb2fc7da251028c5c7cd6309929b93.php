<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(asset('css/admin/detail.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Infor Employee -->
<div class="container">
    <div class="row">
        <div class="col-sm-6 mx-auto  ">
            <div class="f-w-600 text-center text-mute m-b-20">
                <h4 class="text-title-password">Change Password</h4>
            </div>
            <div class="form-group card bg-c-lite-green padding">
                <?php if($errors->any()): ?>
                <div class="alert alert-warning">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?><br />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <form action="<?php echo e(route('change-password.store')); ?>" method="post" class="w-75 mx-auto">
                    <?php echo csrf_field(); ?>
                    <div class=" text-white  m-b-10">
                        <label>Password Currently</label>
                        <input type="password" name="password_current" class="form-control "
                            placeholder="  **************">
                    </div>
                    <div class="  text-white m-b-10">
                        <label>New Password </label>
                        <input type="password" name="password" class="form-control "
                            placeholder="  **************">
                    </div>
                    <div class=" text-white m-b-10">
                        <label>Confirm New Password</label>
                        <input type="password" name="password_confirmation" class="form-control  "
                            placeholder="   **************">
                    </div>
                    <div class=" m-t-40">
                        <button type="submit" class="form-control btn-light b-b-default  ">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/auth/changePassword.blade.php ENDPATH**/ ?>