<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
<div class="alert alert-warning">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($error); ?><br />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<div class="card-header py-3">
    <p class="m-0 font-weight-bold text-primary">
        <a href="<?php echo e(route('groupgoods.index')); ?>" class="border border-primary rounded text-decoration-none">
            Danh sách nhóm hàng</a>
        <span> <i class="fas fa-chevron-right"></i>Sửa thông tin nhóm hàng</span>
    </p>
</div>
<div class="card-body">
    <form method="POST" enctype="multipart/form-data"
        action="<?php echo e(route('groupgoods.update', ['groupgood' => $groupgood->id])); ?>">
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Tên Nhóm hàng</label>
            <div class="col-sm-10">
                <input name="group_name" type="text" class="form-control" placeholder="Group name"
                    value="<?php echo e($groupgood->group_name); ?>">
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Ảnh</label>
            <div class="col-sm-10">
                <input name="group_image" type="file" class="form-control" placeholder="Image">
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Mô tả</label>
            <div class="col-sm-10">
                <input name="group_description" type="text" class="form-control" placeholder="Description"
                    value="<?php echo e($groupgood->group_description); ?>">
            </div>
        </div>
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <button class="btn btn-primary">Sửa</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/groupGoods/edit.blade.php ENDPATH**/ ?>