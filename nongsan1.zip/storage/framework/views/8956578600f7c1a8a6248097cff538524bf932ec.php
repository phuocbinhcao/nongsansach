<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($error); ?><br />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button type="button" class="close" data-miss="alert" aria-label="close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>
<div class="card-header py-3">
    <p class="m-0 font-weight-bold text-primary">
       <a href="<?php echo e(route('customers.index')); ?>" class="border border-primary rounded text-decoration-none">Danh sách khách hàng</a>
        <span> <i class="fas fa-chevron-right"></i>Thêm thông tin khách hàng</span>
    </p>
</div>
<div class="card-body">
    <form method="POST" action="<?php echo e(route('customers.store')); ?>" enctype="multipart/form-data">
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Tên</label>
            <div class="col-sm-10">
                <input name="customer_name" type="text" class="form-control" placeholder="Nguyen Van A">
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">SĐT</label>
            <div class="col-sm-10">
                <input name="customer_phone" type="text" class="form-control" placeholder="+84123456789">
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Email</label>
            <div class="col-sm-10">
                <input name="customer_email" type="text" class="form-control" placeholder="example@gmail.com">
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Địa chỉ</label>
            <div class="col-sm-10">
                <input name="customer_address" type="text" class="form-control"
                    placeholder="Phường( Xã)/ Quận( Huyện)/ Thành Phố( Tỉnh)">
            </div>
        </div>
        <?php echo csrf_field(); ?>
        <button class="btn btn-primary">Thêm</button>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/customer/create.blade.php ENDPATH**/ ?>