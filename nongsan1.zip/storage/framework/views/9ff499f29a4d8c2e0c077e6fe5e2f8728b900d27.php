    <?php $__env->startSection('styles'); ?>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- CSS -->
    
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" />


    <style>
        .container {
            max-width: 600px;

        }

        input[type=text] {
            background: none;
            font-weight: bold;
            border-color: #2e2e2e;
            border-style: solid;
            border-width: 2px 2px 2px 2px;
            outline: none;
            padding: 10px 20px 10px 20px;
        }

        ul.ui-autocomplete {
            color: blue !important;
            -moz-border-radius: 15px;
            border-radius: 15px;
        }

        </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5">

        <form action="form-group"  >
            <!-- For defining autocomplete -->
            Search phone : <input class=" form-control" type="text" id='employeephone' autocomplete="text"> <br><br>

            <!-- For displaying selected option value from autocomplete suggestion -->
            Selected UserID : <input class="form-control" type="text" id='employeeid'> <br> <br>

            Selected UserEmail : <input class="form-control" type="text" id='employeeemail'> <br><br>

            Selected UserName : <input class="form-control" type="text" id='employeename'>

        </form>
    </div>
    <?php $__env->startSection('scripts'); ?>
    <!-- Script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    

    <!-- Script code -->
    <script type="text/javascript">
        // CSRF Token
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $(document).ready(function () {

            $("#employeephone").autocomplete({
                source: function (request, response) {
                    // Fetch data
                    $.ajax({
                        url: "<?php echo e(route('getCustomers')); ?>",
                        type: 'post',
                        dataType: "json",
                        data: {
                            _token: CSRF_TOKEN,
                            search: request.term
                        },
                        success: function (data) {
                            response(data);
                        }
                    });
                },
                select: function (event, ui) {
                    // Set selection
                    $('#employeephone').val(ui.item.phone); // display the selected text
                    $('#employeeid').val(ui.item.value); // save selected id to input
                    $('#employeeemail').val(ui.item.email);
                    $('#employeename').val(ui.item.label);
                    return false;
                }
            });

        });
    </script>
    <?php $__env->stopSection(); ?>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/orders/demo.blade.php ENDPATH**/ ?>