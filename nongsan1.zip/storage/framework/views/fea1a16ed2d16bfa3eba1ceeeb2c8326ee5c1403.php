sfsaf
<?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/users/blockedAccounts.blade.php ENDPATH**/ ?>