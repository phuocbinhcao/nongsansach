<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <p class="m-0 font-weight-bold text-primary">
            <a href="<?php echo e(route('order.index')); ?>" class="border border-primary rounded text-decoration-none">
                Danh sách đơn hàng</a>
            <span> <i class="fas fa-chevron-right"></i>Thông tin</span>
        </p>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Ngày</th>
                        <th>Tên khách hàng</th>
                        <th>Địa chỉ</th>
                        <th>SĐT</th>
                        <th>Công cụ</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Ngày</th>
                        <th>Tên khách hàng</th>
                        <th>Địa chỉ</th>
                        <th>SĐT</th>
                        <th>Công cụ</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->active == 0 && $item->order_customer_phone !== null): ?>

                    <tr>
                        <td><?php echo e($item->created_at); ?></td>
                        <td><?php echo e($item->order_customer_name); ?></td>
                        <td><?php echo e($item->order_customer_address); ?></td>
                        <td><?php echo e($item->order_customer_phone); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('order.getBack', ['id' => $item->id])); ?>"
                                class="d-inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <button class="btn btn-primary">Kích hoạt</button>
                            </form>

                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
<script src="https://unpkg.com/sweetalert@2.1.2/dist/sweetalert.min.js"></script>
<script>
    <?php if(session()->get('success')): ?>

   swal({title: "Thành công",
                text: '<?php echo e(session()->get('success')); ?>',
                icon: "success",

        });


    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/itemDelete/orderDeleted/orderDelete.blade.php ENDPATH**/ ?>