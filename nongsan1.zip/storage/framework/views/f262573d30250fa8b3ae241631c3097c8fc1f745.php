<?php $__env->startSection('styles'); ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo e(config('app.name', 'Laravel')); ?></title>

<!-- CSS -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css" />
 <!-- Default theme -->
 <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/default.min.css" />


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="card-header py-3">
    <p class="m-0 font-weight-bold text-primary">
        <a href="<?php echo e(route('order.index')); ?>" class="border border-primary rounded text-decoration-none">
           Danh sách đơn hàng</a>
        <span> <i class="fas fa-chevron-right"></i>Thêm đơn hàng</span>
    </p>
</div>
<div class="container">
    <div class="card-body ">
        <form method="POST" action="<?php echo e(route('order.store')); ?>">

            <!--Form Orders  -->
            <div class="mb-3 row">
                <div class="col-10 ">
                    <div class="table">
                        <table class="table table-bordered table-product" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Tên sản phẩm</th>
                                    <th>Giá</th>
                                    <?php if(auth()->user()->rolename == 'admin'): ?>
                                    <th>Chức năng</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>STT</th>
                                    <th>Tên sản phẩm</th>
                                    <th>Giá</th>
                                    <?php if(auth()->user()->rolename == 'admin'): ?>
                                    <th>Chức năng</th>
                                    <?php endif; ?>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($pro->active == 1): ?>
                                <tr>
                                    <td><?php echo e($pro->id); ?></td>
                                    <td><?php echo e($pro->product_name); ?></td>
                                    <td><?php echo e(number_format($pro->product_price)); ?></td>
                                    <?php if(auth()->user()->rolename == 'admin'): ?>
                                    <td>
                                        <a href="javascript:" data-url="<?php echo e(route('addToCart', $pro->id)); ?>"
                                            class="add_order btn-sm btn-primary">Thêm</a>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <a class="btn-sm btn-warning" href="<?php echo e(route('showCart')); ?>">👋Hiển thị đơn hàng</a>
            <?php echo csrf_field(); ?>
        </form>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
 <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

<!-- Script -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>







<!-- Script code  -->
<script type="text/javascript">
    // CSRF Token,  Autocomplete
    // var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $(".add_order").on('click', function (e) {
         e.preventDefault();
         let urlCart = $(this).data('url');
          console.log(urlCart);
         $.ajax({
             type: "GET",
             url: urlCart,
             dataType: "json",
             success: function (data) {
                console.log(data);
                 alertify.set('notifier', 'position', 'top-center');
                 alertify.success('Đã thêm sản phẩm!');
             }
         });
     });


    // <script type="text/javascript">
    // $(document).ready(function() {
    // $('select[name="product"]').on('change', function () {
    //     var productID = $(this).val();
    //     if (productID) {
    //         $.ajax({
    //             url: '/panel/orders/create/' + productID,
    //             type: "GET",
    //             dataType: "json",
    //             success: function (data) {
    //                 console.log(data);
    //                 $('tr[name="product_info"]').empty();
    //                 $.each(data, function () {
    //                     $('tr[name="product_info"]').html(

    //                         '<td width="5%">' +  data.id + '</td>\
    //                         <td width="50%">' +  data.product_name + '</td>\
    //                         <td width="30%">' +  data.product_price + '</td>\
    //                         <th><a data-url="<?php echo e(route('addToCart',['id'=>'1'])); ?>" class="add btn-sm btn-primary" >add</a></th>'
    //                     );
    //                 });




</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/orders/create.blade.php ENDPATH**/ ?>