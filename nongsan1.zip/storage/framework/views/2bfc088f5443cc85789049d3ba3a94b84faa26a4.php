<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- DataTales Example -->
<div class="card shadow mb-4  bg-primary">
    <div class="card-header py-3">
        <p class="m-0 font-weight-bold text-primary">
            <a href="<?php echo e(route('groupgoods.index')); ?>" class="border border-primary rounded text-decoration-none">
                Danh sách nhóm hàng</a>
            <span> <i class="fas fa-chevron-right"></i>Thông tin nhóm hàng</span>
        </p>
    </div>

    <div class="card-body  w-50 mx-auto">
        <div class="card-header">
            Thông tin
        </div>
        <ul class="list-group list-group-flush  ">
            <li class="list-group-item">
                <strong>STT</strong>
                <span><?php echo e($groupgood->id); ?></span>
            </li>
            <li class="list-group-item">
                <strong>Nhóm Hàng: </strong>
                <span><?php echo e($groupgood->group_name); ?></span>
            </li>
            <li class="list-group-item">
                <strong>Ảnh</strong>
                <span class=" d-flex justify-content-center  "><img src="<?php echo e(url('img/groupgoods', $groupgood->group_image)); ?>"
                   class="border rounded" width="150px" alt="<?php echo e($groupgood->group_image); ?>"> </span>
            </li>
            <li class="list-group-item">
                <strong>Mô tả</strong>
                <span><?php echo e($groupgood->group_description); ?></span>
            </li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/groupGoods/showdetail.blade.php ENDPATH**/ ?>