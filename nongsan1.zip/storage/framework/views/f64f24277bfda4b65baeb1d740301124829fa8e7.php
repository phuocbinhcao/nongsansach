<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Danh sách đơn hàng</h6>
    </div>

    <div class="card-body">
        <a class="btn btn-outline-primary mb-3" href="<?php echo e(route('order.create')); ?>">Thêm đơn hàng</a>
        <?php if(auth()->user()->rolename == 'admin'): ?>
        <a href="<?php echo e(route('order.tableDelete')); ?>" class="badge badge-danger mb-3">Đơn hàng đã xóa</a>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Ngày</th>
                        <th>Khách hàng</th>
                        <th>Tổng tiền (Vnd)</th>
                        <th>Trạng thái</th>
                        <th>Công cụ</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Ngày</th>
                        <th>Khách hàng</th>
                        <th>Tổng tiền (Vnd)</th>
                        <th>Trạng thái</th>
                        <th>Công cụ</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->active == 1 ): ?>

                    <tr>
                        <td width="10%" ><?php echo e($item->created_at); ?></td>
                        <td>
                            <?php echo e($item->order_customer_name); ?> <br>
                           Địa chỉ: <?php echo e($item->order_customer_address); ?> <br>
                           SĐT: <?php echo e($item->order_customer_phone); ?>

                        </td>
                        <td ><?php echo e(number_format($item->order_total_price)); ?></td>
                        <td ><?php echo e($item->order_status); ?></td>
                        <td>
                            <a href="<?php echo e(route('order.edit', ['id' => $item->id])); ?>"><button
                                    class="btn btn-primary">Sửa</button></a>
                            <a href="<?php echo e(route('order.show',['id'=>$item->id])); ?> "><button
                                    class="btn btn-primary">Chi tiết</button></a>
                            <?php if(auth()->user()->rolename == 'admin'): ?>

                            <form method="POST" action="<?php echo e(route('order.delete', ['id' => $item->id])); ?>"
                                class="d-inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <button class="btn btn-danger">Xóa</button>
                            </form>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>

<script src="https://unpkg.com/sweetalert@2.1.2/dist/sweetalert.min.js"></script>
<script>
    <?php if(session()->get('success')): ?>

   swal({title: "Thành công",
                text: '<?php echo e(session()->get('success')); ?>',
                icon: "success",

        });


    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/orders/index.blade.php ENDPATH**/ ?>