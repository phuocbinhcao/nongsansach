<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('css/admin/detailProduct.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card-header py-3">
    <p class="m-0 font-weight-bold text-primary">
        <a href="<?php echo e(route('order.index')); ?>" class="border border-primary rounded  ">
            Trở lại</a>
        <span> <i class="fas fa-chevron-right"></i>Thông tin chi tiết</span>
    </p>
</div>
<div class="container bg-primary">
    <div class="row">
        <div class="card-title border bg-white col-md-4 text-center mt-2 ">

            <span>Tên: <?php echo e($order->customer_name); ?></span><br>
            <span>SĐT: <?php echo e($order->customer_phone); ?></span><br>
            <span>Email: <?php echo e($order->customer_email); ?></span><br>
            <span>Địa chỉ: <?php echo e($order->customer_address); ?></span>
        </div>
    </div>
    <div class="row">
        <div class="card col-sm-12 mb-2">
            <div class="card-title">
                <span class="des">Bảng đơn hàng</span>
            </div>
            <table class="table table-hover  table-bordered">
                <thead class="bg-primary text-white">
                    <tr>
                        <th width="10%">STT</th>
                        <th width="30%">Tên sản phẩm</th>
                        <th width="10%">Số lượng</th>
                        <th width="30%">Giá (VND)</th>
                        <th width="30%">Ngày </th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total = 0;
                    ?>
                    <?php $__currentLoopData = $dataOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $total += $item->order_detail_price ;
                    ?>
                    <tr>
                        <td width="10%"><?php echo e($item->id); ?></td>
                        <td width="10%"><?php echo e($item->product_name); ?></td>
                        <td width="10%"><?php echo e($item->order_detail_quantity); ?></td>
                        <td width="30%"><?php echo e(number_format($item->order_detail_price)); ?></td>
                        <td width="10%"><?php echo e($item->created_at); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <h2 name="total_price">Tổng tiền: <?php echo e(number_format($total)); ?> VNĐ</h2>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/orders/showDetail.blade.php ENDPATH**/ ?>