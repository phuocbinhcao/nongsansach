<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Danh sách nhân viên</h6>
    </div>
    <?php if(Auth::user()->rolename == 'admin'): ?>
    <div class="p-2">
        <a href="<?php echo e(route('employees.create')); ?>"><button class="btn btn-primary">Thêm Nhân Viên</button></a>
    </div>
    <?php endif; ?>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Tên</th>
                        <th>SĐT</th>
                        <th>Số CMND</th>
                        <th>Địa chỉ</th>
                        <th>Công cụ</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>STT</th>
                        <th>Tên</th>
                        <th>SĐT</th>
                        <th>Số CMND</th>
                        <th>Địa chỉ</th>
                        <th>Công cụ</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $em): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($em->active == 1): ?>

                    <tr>
                        <td><?php echo e($em->id); ?></td>
                        <td><?php echo e($em->employee_name); ?></td>
                        <td><?php echo e($em->employee_phone); ?></td>
                        <td><?php echo e($em->employee_identity); ?></td>
                        <td><?php echo e($em->employee_address); ?></td>
                        <td>
                            <?php if(Auth::user()->rolename == 'admin'): ?>
                            <a href="<?php echo e(route('employees.show',$em->id)); ?>"><button
                                class="btn btn-primary">Chi tiết</button></a>
                            <a href="<?php echo e(route('employees.edit', $em->id)); ?>"><button
                                    class="btn btn-primary">Sửa</button></a>
                            <form method="POST" action="<?php echo e(route('employees.destroy',$em->id)); ?>"
                                class="d-inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-danger">Xóa</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>

<script src="https://unpkg.com/sweetalert@2.1.2/dist/sweetalert.min.js"></script>
<script>
    <?php if(session()->get('success')): ?>

   swal({title: "Thành công",
                text: '<?php echo e(session()->get('success')); ?>',
                icon: "success",

        });


    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/employee/index.blade.php ENDPATH**/ ?>