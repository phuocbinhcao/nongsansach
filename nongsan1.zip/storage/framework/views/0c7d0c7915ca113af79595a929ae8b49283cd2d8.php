<?php $__env->startSection('styles'); ?>

<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css" />
 <!-- Default theme -->
 <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/default.min.css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
<div class="alert alert-warning">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($error); ?><br />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<div class="card-header py-3">
    <p class="m-0 font-weight-bold text-primary">
        <a href="<?php echo e(route('order.index')); ?>" class="border border-primary rounded text-decoration-none">
            Danh sách đơn hàng</a>
        <span> <i class="fas fa-chevron-right"></i>Sửa thông tin đơn hàng</span>
    </p>
</div>
<div class="card-body">
    <form method="POST" action="<?php echo e(route('order.update',$order->id)); ?>">
        <div class="mb-3 row text-center">
            <label class="col-sm-1 col-form-label">Tên</label>
            <div class="col-sm-4">
                <input name="order_customer_name" type="text" class="form-control"
                    value="<?php echo e($order->order_customer_name); ?>">
            </div>
            <label class="col-sm-1 col-form-label">SĐT</label>
            <div class="col-sm-4">
                <input name="order_customer_phone" type="text" class="form-control"
                    value="<?php echo e($order->order_customer_phone); ?>">
            </div>
        </div>
        <div class="mb-3 row text-center">
            <label class="col-sm-1 col-form-label">Địa chỉ</label>
            <div class="col-sm-4">
                <input name="order_customer_address" type="text" class="form-control"
                    value="<?php echo e($order->order_customer_address); ?>">
            </div>
            <label class="col-sm-1 col-form-label">Email</label>
            <div class="col-sm-4">
                <input name="order_customer_email" type="text" class="form-control"
                    value="<?php echo e($order->order_customer_email); ?>">
            </div>
        </div>
        <div class="mb-3 row text-center">
            <label class="col-sm-1 col-form-label">Ghi chú</label>
            <div class="col-sm-4">
                <textarea name="order_note" type="text" class="form-control"
                    value="<?php echo e($order->order_note); ?>"><?php echo e($order->order_note); ?></textarea>
            </div>
            <label class="col-sm-1 col-form-label">Trạng thái</label>
            <div class="col-sm-4">
                <select name="order_status" class="form-control">
                    <option value="0"><?php echo e($order->order_status); ?></option>
                    <option value="Tiếp nhận">Tiếp nhận</option>
                    <option value="Đang giao">Đang giao</option>
                    <option value="Đã giao">Đã giao</option>
                    <option value="Hủy">Hủy</option>
                </select>
            </div>
        </div>
        <div class="mb-3 row text-center">
            <label class="col-sm-1 col-form-label">Chi tiết đơn hàng</label>
            <div class="col-sm-9">
                <table class="table table-hover table-bordered">
                    <thead class="bg-primary text-white">
                        <tr>
                            <th>Tên sản phẩm</th>
                            <th>Ký hiệu</th>
                            <th>Số lượng (Kg)</th>
                            <th>Giá (VND)</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dataOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($item->product_name); ?></td>
                            <td><?php echo e($item->product_symbol); ?></td>
                            <td><input type="number" name="order_detail_quantity" min="1"  class="w-25 quatity"
                                    value="<?php echo e($item->order_detail_quantity); ?>"></td>
                            <td><?php echo e(number_format($item->order_detail_price)); ?></td>
                            <td>
                                <a href="javascript:" data-id="<?php echo e($item->id); ?>"
                                    data-url="<?php echo e(route('order.editCart',$item->id)); ?>"
                                    class="btn-sm btn-primary cart_update">Sửa</a>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php echo csrf_field(); ?>
        <button class="btn btn-primary">Sửa</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
 <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

<script>
    function cartUpdate(event) {
        event.preventDefault();
        let urlUpdateCart = $(this).data('url');
        let id = $(this).data('id');
        let quatity = $(this).parents('tr').find('input.quatity').val();
        $.ajax({
            type: "GET",
            url: urlUpdateCart,
            data: {
                id: id,
                quatity: quatity,
            },
            success: function (data) {
                    $('.table').load(' .table');
                    alertify.set('notifier', 'position', 'top-center');
                    alertify.success('Thay đổi thành công');
            }
        });
    }
    $(function () {
        $(document).on('click', '.cart_update', cartUpdate);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/orders/edit.blade.php ENDPATH**/ ?>