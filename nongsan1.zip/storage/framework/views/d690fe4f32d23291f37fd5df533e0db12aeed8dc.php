<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
<div class="alert alert-warning">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($error); ?><br />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<div class="card-header py-3">
    <p class="m-0 font-weight-bold text-primary">
        <a href="<?php echo e(route('product-type.index')); ?>" class="border border-primary rounded text-decoration-none">
            Danh sách loại sản phẩm </a>
        <span> <i class="fas fa-chevron-right"></i>Thêm thông tin loại sản phẩm</span>
    </p>
</div>
<div class="card-body">
    <form method="post" action="<?php echo e(route('product-type.store')); ?>">
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Loại sản phẩm</label>
            <div class="col-sm-10">
                <input name="product_type_name" type="text" class="form-control" placeholder="Loại sản phẩm">
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Mô tả</label>
            <div class="col-sm-10">
                <textarea name="product_type_description" type="text" class="form-control"
                    placeholder="Mô tả loại sản phẩm"></textarea>
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-2 col-form-label">Nhóm hàng</label>
            <div class="col-sm-10">
                <select name="group_goods_id" type="text" class="form-control">
                    <?php $__currentLoopData = $groupGoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($name->id); ?>"><?php echo e($name->group_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <?php echo csrf_field(); ?>
        <button class="btn btn-primary">Thêm</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/panel/ProductType/create.blade.php ENDPATH**/ ?>